function mod(){
    EmptyDisplay()
    ansField.value = ansField.value + "%";
  }
  
  
  function Handle_mod() {
  
    currentExpression += `${currentResult}mod`;
    expression += `${currentResult}^`;  // expression
    currentResult = "";
    PrintResult();
    PrintExpression();
  }
  function Handle_Pi(){
    ansField.value = ansField.value + "3.1415926535897932384626433832795";
  }
  function Handle_e(){
    ansField.value = ansField.value + "2.7182818284590452353602874713527";
  }
  function Handle_ce(){
    previousInput.innerText = "";
    ansField.value="";
    calculation="";
  }
  function Handle_back(){
    ansField.value = ansField.value.slice(0,-1);
  }
  function Handle_square(){
    previousInput.innerText+=`sqr(${ansField.value})`;
    ansField.value = Math.pow(ansField.value,2)
  }
  function Handle_cube(){
    previousInput.innerText+=`cube(${ansField.value})`;
    ansField.value = Math.pow(ansField.value,3)
  }
  function Handle_1byx(){
    previousInput.innerText+=`1/(${ansField.value})`;
    ansField.value = 1/ansField.value;
  }
  function Handle_abs(){
    previousInput.innerText+=`abs(${ansField.value})`;
    ansField.value = Math.abs(ansField.value);
  }
  function Handle_sqrt(){
    previousInput.innerHTML+=`2&#8730;(${ansField.value})`;
    ansField.value = Math.sqrt(ansField.value);
  }
  
  function Handle_cubeqrt(){
    previousInput.innerHTML+=`3&#8730;(${ansField.value})`;
    ansField.value = Math.cbrt(ansField.value);
  }
  function Handle_log(){
    previousInput.innerHTML+=`log(${ansField.value})`;
    ansField.value = Math.log10(ansField.value);
  }
  function Handle_ln(){
    previousInput.innerHTML+=`ln(${ansField.value})`;
    ansField.value = Math.log(ansField.value);
  }
  
  function exponentiation(baseValue, exponent) {
    return Math.pow(baseValue, exponent);
  }
  
  function root(baseValue, rootValue) {
    return Math.pow(baseValue, 1.0 / rootValue);
  }
  function Handle_fact(){
    previousInput.innerText+=`fact(${ansField.value})`;
    ansField.value = Factroial(parseFloat(ansField.value));
  }
  function negate()
  {
    if((parseFloat(ansField.value))>0){
      ansField.value = '-' + ansField.value;
    }
    else if((parseFloat(ansField.value))<0){
      ansField.value = ansField.value.slice(1);
    }
  }



  //---------------------Handle function----
function decimalToDMS(deg) {
    let degrees = Math.floor(deg);
    let minutesFloat = (deg - degrees) * 60;
    let minutes = Math.floor(minutesFloat);
    let seconds = (minutesFloat - minutes) * 60;
  
    return `${degrees}° ${minutes}' ${seconds.toFixed(2)}"`;
  }
  function DMSToDecimal(degrees, minutes, seconds) {
    return degrees + minutes / 60 + seconds / 3600;
  }
  
  
  function cellingValue(){
    previousInput.innerText+=`Cell(${ansField.value})`;
    ansField.value =Math.ceil(parseFloat(ansField.value));
  }
  function floorValue(){
    previousInput.innerText+=`floor(${ansField.value})`;
    ansField.value =Math.floor(parseFloat(ansField.value));
  }
  function randValue(){
   // previousInput.innerText+=`random(${ansField.value})`;
    ansField.value =Math.random(parseFloat(ansField.value));
  }
  function DMS(){
    previousInput.innerText+=`dms(${ansField.value})`;
    ansField.value =decimalToDMS(parseFloat(ansField.value));
  }
  function DEG(){
    previousInput.innerText+=`deg(${ansField.value})`;
    ansField.value =DMSToDecimal(parseFloat(ansField.value));
  }