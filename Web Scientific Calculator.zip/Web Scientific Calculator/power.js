class PowerOperations {
    static inverse(x) {
        if (x !== 0) {
            return 1 / x;
        }
        return 0;
    }

    static calculateTrigonometricValue(angle, inputUnit) {
        let angleRad;
        switch (inputUnit) {
            case "RAD":
                angleRad = angle;
                break;
            case "DEG":
                angleRad = angle * (180.0 / Math.PI);
                break;
            case "GRAD":
                angleRad = angle * (200 / Math.PI);
                break;
            default:
                throw new Error("Invalid unit. Enter units are 'RAD', 'DEG', and 'GRAD'.");
        }
        return angleRad;
    }

    static sine(angle) {
        return Math.sin(angle);
    }

    static cosine(angle) {
        const epsilon = 1e-10;
        if (Math.cos(angle) < epsilon) {
            return 0;
        } else {
            return Math.cos(angle);
        }
    }

    static tangent(angle) {
        return Math.tan(angle);
    }

    static cot(angle) {
        return Math.cos(angle) / Math.sin(angle);
    }

    static sec(angle) {
        return 1 / Math.cos(angle);
    }

    static cosec(angle) {
        return 1 / Math.sin(angle);
    }

    static sineInverse(angle, status) {
        return this.calculateTrigonometricValue(Math.asin(angle), status);
    }

    static cosineInverse(angle, status) {
        return this.calculateTrigonometricValue(Math.acos(angle), status);
    }

    static tangentInverse(angle, status) {
        return this.calculateTrigonometricValue(Math.atan(angle), status);
    }

    static cotInverse(angle, status) {
        return this.calculateTrigonometricValue(Math.atan(1 / angle), status);
    }

    static secInverse(angle, status) {
        return this.calculateTrigonometricValue(Math.acos(1 / angle), status);
    }

    static cosecInverse(angle, status) {
        return this.calculateTrigonometricValue(Math.asin(1 / angle), status);
    }

    static sineHyp(angle) {
        return Math.sinh(angle);
    }

    static cosineHyp(angle) {
        return Math.cosh(angle);
    }

    static tangentHyp(angle) {
        return Math.tanh(angle);
    }

    static cosecHyp(angle) {
        return 1 / Math.sinh(angle);
    }

    static secHyp(angle) {
        return 1 / Math.cosh(angle);
    }

    static cotHyp(angle) {
        return 1 / Math.tanh(angle);
    }

    static absoluteFunction(input) {
        return Math.abs(input);
    }

    static floorFunction(input) {
        return Math.floor(input);
    }

    static ceilingFunction(input) {
        return Math.ceil(input);
    }

    static randomFunction() {
        return Math.random();
    }

    static convertDegreeToRadians(angle) {
        return (Math.PI / 180) * angle;
    }

    static convertRadiansToDegree(rad) {
        return (180 / Math.PI) * rad;
    }

    static convertGradientToDegree(angle) {
        return (9 / 10) * angle;
    }

    static convertToDMS(angle) {
        const degrees = Math.floor(angle);
        const minutes = (angle - degrees) * 60;
        const minutesInt = Math.floor(minutes);
        const seconds = (minutes - minutesInt) * 60;

        const result = degrees + minutesInt / 100.0 + seconds / 10000.0;

        return result;
    }

    static exponentiation(baseValue, exponent) {
        return Math.pow(baseValue, exponent);
    }

    static root(baseValue, rootValue) {
        return Math.pow(baseValue, 1.0 / rootValue);
    }

    static squareRoot(number) {
        if (number < 0) {
            throw new Error("Invalid input");
        }
        return Math.sqrt(number);
    }

    static cubeRoot(number) {
        if (number < 0) {
            return -Math.pow(-number, 1.0 / 3.0);
        } else {
            return Math.pow(number, 1.0 / 3.0);
        }
    }

    static log(x, baseValue) {
        return Math.log(x) / Math.log(baseValue);
    }

    static ln(x) {
        return Math.log(x);
    }

    static ePowerx(x) {
        return Math.exp(x);
    }

    static factorial(n) {
        if (n < 0) {
            throw new Error("Invalid input");
        }

        if (n === 0 || n === 1) {
            return 1;
        }

        let result = 1;
        for (let i = 2; i <= n; i++) {
            result *= i;
        }

        return result;
    }

    static convertToScientificNotation(number) {
        return number.toExponential(5);
    }
}

// Example usage:
// PowerOperations.inverse(5);
// PowerOperations.sine(30);
// PowerOperations.absoluteFunction(-10);
// PowerOperations.exponentiation(2, 3);
// etc.
