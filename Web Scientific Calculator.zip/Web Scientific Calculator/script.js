
// ------------------------click events on various functions

const previousInput = document.querySelector("#previousInput");
// const inputField = document.querySelector("#currentInput input");
const ansField = document.getElementById('ansInput');
var calculation="";
let currentResult=0;
let trigofun= false;

//    function to convert 
function calculateTrigonometricValue(inputField, selectedDegreeUnit) {
  let angleRad;
  switch (selectedDegreeUnit) {
      case "RAD":
          angleRad = inputField;
          break;
      case "DEG":
          angleRad = inputField * ( Math.PI/180.0 );
          break;
      case "GRAD":
          angleRad = inputField * ( Math.PI/200);
          break;
      default:
          throw new Error("Invalid unit. Enter units are 'RAD', 'DEG', and 'GRAD'.");
  }
  return angleRad;
}

function calculateAngle(inputField, selectedDegreeUnit) {
  let angleRad;
  switch (selectedDegreeUnit) {
      case "RAD":
          angleRad = inputField;
          break;
      case "DEG":
          angleRad = inputField * (180.0/ Math.PI );
          break;
      case "GRAD":
          angleRad = inputField * (200/Math.PI);
          break;
      default:
          throw new Error("Invalid unit. Enter units are 'RAD', 'DEG', and 'GRAD'.");
  }
  return angleRad;
}

//  ------------- toggle status
let selectedDegreeUnit = "DEG";
const degreeUnitToggleElement = document.querySelector(
  "#toggleButtons #degreeUnit"
);

degreeUnitToggleElement.addEventListener("click", function () {
  if (degreeUnitToggleElement.innerText == "DEG") {
    degreeUnitToggleElement.innerText = "RAD";
    selectedDegreeUnit = "RAD";
  } else if (degreeUnitToggleElement.innerText == "RAD") {
    degreeUnitToggleElement.innerText = "GRAD";
    selectedDegreeUnit = "GRAD";
  } else if (degreeUnitToggleElement.innerText == "GRAD") {
    degreeUnitToggleElement.innerText = "DEG";
    selectedDegreeUnit = "DEG";
  }
  console.log(`currently degree unit is set to: ${selectedDegreeUnit}`);
});

 

// ------------- toggle the F-E display format button
let exponentialFormatEnabled = false;
var button = document.getElementById("exponentialNotation");
button.addEventListener("click", function () {
  this.classList.toggle("removeAfter");
  if (exponentialFormatEnabled) {
    exponentialFormatEnabled = false;
  } else {
    exponentialFormatEnabled = true;
  }
  console.log(
    `currently exponential format set to: ${exponentialFormatEnabled}`
  );
});



function Dot(){
  let lastChar = ansField.value.slice(-1);
    if (lastChar !== '.') {
      ansField.value += ".";
    }
}
function EmptyDisplay(){
  if(previousInput.innerText.includes('=')){
    ansInput.value="";
    calculation="";
    previousInput.innerText="";
      }
}

function Digit7() {
  EmptyDisplay();
  ansField.value = ansField.value + "7";
}
function Digit8(){
  EmptyDisplay()
  ansField.value = ansField.value + "8";
}
function Digit9(){
  EmptyDisplay()
  ansField.value = ansField.value + "9";
}
function Digit4(){
  EmptyDisplay()
  ansField.value = ansField.value + "4";
}
function Digit5(){
  EmptyDisplay()
  ansField.value = ansField.value + "5";
}
function Digit6(){
  EmptyDisplay()
  ansField.value = ansField.value + "6";
}
function Digit1(){
  EmptyDisplay()
  ansField.value = ansField.value + "1";
}
function Digit2(){
  EmptyDisplay()
  ansField.value = ansField.value + "2";
}
function Digit3(){
  EmptyDisplay()
  ansField.value = ansField.value + "3";
}
function zero(){
  EmptyDisplay()
  ansField.value = ansField.value + "0";
}







//----------------- BODMAS----------------//
function HandleBrackets(bracket) {
  let currentExpression = previousInput.innerHTML+ansInput.value;
  let operatorToAdd = '';

  // Check if an operator is already present before appending a bracket
  if (bracket == 'open') {
      if (currentExpression === '') {      
          operatorToAdd = '';
      } else {
         
          const lastChar = currentExpression[currentExpression.length - 1];
          if (!['+', '-', '*', '/'].includes(lastChar)) {
              operatorToAdd = '*';
          }
      }
  }

  // Append the operator and the bracket to the expression
  if (bracket == 'open') {
      previousInput.innerText += ansInput.value+operatorToAdd + '(';
      calculation+=ansInput.value+operatorToAdd + '(';
     // previousInput.innerText +=  ansInput.value+operatorToAdd + '(';
  } else {
     // inputField.value += ansInput.value+operatorToAdd + ')';
      previousInput.innerText += ansInput.value+operatorToAdd + ')';
      calculation+=ansInput.value+operatorToAdd + ')';
  }
  ansInput.value = "";
  }



function AppendArithmeticOp(op) {

  if(previousInput.innerText.includes('=')){
    previousInput.innerText=ansField.value+op;        
    calculation=ansField.value+op;      
  }
  else{
    const inputField = document.getElementById("ansInput");
    const lastChar = inputField.value.slice(-1); // Get the last character of the input value
  
    // Check if the last character is a number
    const isLastCharNumber = !isNaN(parseFloat(lastChar)) && isFinite(lastChar);
    if (isLastCharNumber || lastChar=='(' || lastChar==')' || lastChar=='') {
      if(trigofun){
        previousInput.innerText+=op;
        calculation+=(ansField.value+op);
        trigofun=false;
       
      }
      else{
        previousInput.innerText+=ansField.value+op;   
        calculation+=(ansField.value+op);
        ansField.value="";
      }     
    }
    else {
      // Replace the last character (operator) with the new operator
      inputField.value = inputField.value.slice(0, -1) + op;
    } 
  }
}


function evaluateExp(){ 
  //  previousInput.innerText+=`(${inputField.value})`;
  if(trigofun){
    previousInput.innerText+='=';
    trigofun=false;
  }
  else{
    previousInput.innerText+=ansField.value+'=';
  }
  
  calculation+=ansField.value;
  ansField.value =eval(calculation);
}





// ---------------------------------------
// ---------------------------------------
// ---------------------------------------
// ---------------------------------------
// ---------------------------------------
function Factroial(n) {
  // Check if the input is a non-negative integer or a decimal value
  if (!Number.isInteger(n) || n < 0) {
      return "Factorial is defined only for non-negative integers.";
  }
  
  // Handle factorial of 0
  if (n === 0) {
      return 1;
  }

  // If the input is a decimal value, calculate the factorial using the gamma function
  if (!Number.isInteger(n)) {
      return gamma(n + 1);
  }

  // Otherwise, calculate the factorial of a non-negative integer
  let result = 1;
  for (let i = 2; i <= n; i++) {
      result *= i;
  }
  return result;
}


// Gamma function implementation for handling decimal values
function gamma(x) {
  // Constants
  let g = 7;
  let p = [
      0.99999999999980993,
      676.5203681218851,
      -1259.1392167224028,
      771.32342877765313,
      -176.61502916214059,
      12.507343278686905,
      -0.13857109526572012,
      9.9843695780195716e-6,
      1.5056327351493116e-7
  ];

  if (x < 0.5) {
      return Math.PI / (Math.sin(Math.PI * x) * gamma(1 - x));
  }

  x -= 1;

  let a = p[0];
  let t = x + g + 0.5;
  for (let i = 1; i < p.length; i++) {
      a += p[i] / (x + i);
  }

  return Math.sqrt(2 * Math.PI) * Math.pow(t, x + 0.5) * Math.exp(-t) * a;
}




function ExpConverter() {

  if (exponentialFormatEnabled) {
    exponentialFormatEnabled = false;

    // Get the input value in scientific notation ansInput
    const scientificValue = document.getElementById("ansInput").value;

    // Convert the scientific notation to a regular number
    const number = parseFloat(scientificValue);

    // Update the input field value with the regular number
    document.getElementById("ansInput").value = number;
  } else {
    exponentialFormatEnabled = true;

    // Get the input value
    const inputValue = document.getElementById("ansInput").value;

    // Convert the input value to a number
    const number = parseFloat(inputValue);

    // Convert the number to scientific notation
    const scientificNotation = number.toExponential();

    // Update the input field value with the scientific notation
    document.getElementById("ansInput").value = scientificNotation;
  }
}


// ------------- focus the input field

// -------------- collapse trigo / functions
