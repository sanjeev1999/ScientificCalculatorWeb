// -------------History
let history;
document.querySelector("#historyBtn").style.borderBottom = "5px soli  d blue";
if (history == undefined) {
  history = "No history";
}
RenderHistoryInfo();

document.querySelector("#historyBtn").addEventListener("click", function () {
  if (this.style.borderBottom != "5px solid blue") {
    document.querySelector("#historyBtn").style.borderBottom = "5px solid blue";
    document.querySelector("#memoryBtn").style.borderBottom = "0px solid blue";
    RenderHistoryInfo();
  }
});
function RenderHistoryInfo() {
  document.getElementById("memoryAndHistorySection").innerText = history;
}



//----memory------------

let memory=0;
if (memory == undefined) {
 memory = "Nothing Saved";
}
document.querySelector("#memoryBtn").addEventListener("click", function () {
  if (this.style.borderBottom != "5px solid blue") {
    document.querySelector("#memoryBtn").style.borderBottom = "5px solid blue";
    document.querySelector("#historyBtn").style.borderBottom = "0px solid blue";
    
    RenderMemoryInfo();
  }
});

function RenderMemoryInfo() {
  document.getElementById("memoryAndHistorySection").innerText = parseFloat(memory);
}

function memorystore(){
  memory= parseFloat(ansField.value);
  RenderMemoryInfo();
}
function memoryrecol(){
  ansField.value=memory;
  RenderMemoryInfo();
}
function memoryplus(){
 
    memory= parseFloat(memory);
    memory+= parseFloat(ansField.value );
    RenderMemoryInfo();
   
}
function memoryMinus(){
  
  memory= parseFloat(memory);
  memory-=parseFloat(ansField.value );
  RenderMemoryInfo();
 
}
function memoryclear(){
  memory=0 ;
  RenderMemoryInfo();
}
