
document
  .querySelector("#trigoFunctions")
  .addEventListener("click", function () {
    document.querySelector("#functionCollapse").style.display = "none";
    if (
      document.querySelector("#trigoCollapseFunctions").style.display != "none"
    ) {
      document.querySelector("#trigoCollapseFunctions").style.display = "none";
    } else {
      document.querySelector("#trigoCollapseFunctions").style.display = "block";
    }
  });

// -------------- collpase functions
document.querySelector("#functions").addEventListener("click", function () {
  document.querySelector("#trigoCollapseFunctions").style.display = "none";
  if (document.querySelector("#functionCollapse").style.display != "none") {
    document.querySelector("#functionCollapse").style.display = "none";
  } else {
    document.querySelector("#functionCollapse").style.display = "block";
  }
});

let elem = document.querySelectorAll('#functionCollapse div button');
for (let el of elem) {
  el.addEventListener('click',function(){
    document.querySelector("#functionCollapse").style.display = "none";
  })
}

// -------------- handling display of trigo methods
let secondButtonClicked = false;
document.getElementById('secondTrigoMethods').addEventListener('click', function(){
  if(secondButtonClicked){
    secondButtonClicked = false;
    this.classList.remove("selected");
  }
  else{
    secondButtonClicked = true;
    this.classList.add("selected");
  }
  RedefineTrigoMethods();
})
let hypButtonClicked = false;
document.getElementById('hypTrigoMethods').addEventListener('click', function(){
  if(hypButtonClicked){
    hypButtonClicked = false;
    this.classList.remove("selected");
  }
  else{
    hypButtonClicked = true;
    this.classList.add("selected");
  }
  RedefineTrigoMethods();
})

function RedefineTrigoMethods(){
  let classToTarget = "trigo";
  if(secondButtonClicked){
    classToTarget+="1";
  }
  else{
    classToTarget+="0";
  }
  if(hypButtonClicked){
    classToTarget+="1";
  }
  else{
    classToTarget+="0";
  }
  let elementToHide = document.querySelectorAll("#trigoCollapseFunctions .function");
  for (let el of elementToHide) {
    el.classList.remove("displayInitial");
    el.classList.add("displayNone");
  }

  let elementToDisplay = document.querySelectorAll("#trigoCollapseFunctions ."+classToTarget);
    for (let el of elementToDisplay) {
      el.classList.remove("displayNone");
      el.classList.add("displayInitial");
    }
}

// -------------- collapse 2nd functions
document.querySelector("#secondMethods").addEventListener("click", function () {
  let x = document.querySelectorAll("#operations .displayInitial");
  let y = document.querySelectorAll("#operations .displayNone");
  for (let el of x) {
    el.classList.remove("displayInitial");
    el.classList.add("displayNone");
  }

  for (let el of y) {
    el.classList.remove("displayNone");
    el.classList.add("displayInitial");
  }
});


function sin(){
   
    var tempinput= previousInput.innerText;
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`sin(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult = Math.sin(parseFloat(calculateTrigonometricValue(num,selectedDegreeUnit)));
    ansField.value=currentResult;
    
  }
  
  
  // function sin(){
  //   previousInput.innerText+=`sin(${inputField.value})`;
  //   inputField.value = Math.sin(parseFloat(calculateTrigonometricValue(inputField.value,selectedDegreeUnit)));
  // }
    function cos(){
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`cos(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult = Math.cos(parseFloat(calculateTrigonometricValue(num,selectedDegreeUnit)));
    ansField.value=currentResult;
  }
    function tan(){
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`tan(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult = Math.tan(parseFloat(calculateTrigonometricValue(num,selectedDegreeUnit)));
    ansField.value=currentResult;
    if(ansField.value>1000000000){
      ansField.value= Infinity;
    }
  }
  function cosec(){
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`cosec(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult = 1/Math.sin(parseFloat(calculateTrigonometricValue(num,selectedDegreeUnit)));
    ansField.value=currentResult;
  }
  function sec(){
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`sec(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult =1/ Math.cos(parseFloat(calculateTrigonometricValue(num,selectedDegreeUnit)));
    ansField.value=currentResult;
  }
  function cot(){
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`cot(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult = 1/Math.tan(parseFloat(calculateTrigonometricValue(num,selectedDegreeUnit)));
    ansField.value=currentResult;
    ansFieldField.value = Math.round(ansField.value * 1e10) / 1e10;
  } 
  
   // ----------trigo inverse FUnction
  function sinInverse(){
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`sin^(-1)(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult = calculateAngle((Math.asin(parseFloat(ansField.value))),selectedDegreeUnit);
    ansField.value=currentResult;
 
  }
  function cosInverse(){
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`cos^(-1)(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult = calculateAngle((Math.acos(parseFloat(ansField.value))),selectedDegreeUnit);
    ansField.value=currentResult;
  }
  function tanInverse(){
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`tan(-1)(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult = calculateAngle((Math.atan(parseFloat(ansField.value))),selectedDegreeUnit);
    ansField.value=currentResult;
  }
  function cotInverse(){
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`cot(-1)(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult = calculateAngle((Math.atan(1/parseFloat(ansField.value))),selectedDegreeUnit);
    ansField.value=currentResult;
  }
  function secInverse(){
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`sec(-1)(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult = calculateAngle((Math.acos(1/parseFloat(ansField.value))),selectedDegreeUnit);
    ansField.value=currentResult;
  }
  function cscInverse(){
    var inputnum= ansField.value;
    var num=ansField.value;
     trigofun= true;
    inputnum=`sec(-1)(${inputnum})`;
    previousInput.innerText +=  inputnum;  
    currentResult = calculateAngle((Math.acsc(1/parseFloat(ansField.value))),selectedDegreeUnit);
    ansField.value=currentResult;
  }
 
  